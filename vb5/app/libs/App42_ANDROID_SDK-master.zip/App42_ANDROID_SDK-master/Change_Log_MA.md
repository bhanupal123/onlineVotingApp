* [Release Version 3.1](https://github.com/shephertz/App42_ANDROID_SDK/blob/master/Change_Log_MA.md#version-31)
* [Release Version 3.0](https://github.com/shephertz/App42_ANDROID_SDK/blob/master/Change_Log_MA.md#version-30)
* [Release Version 2.0](https://github.com/shephertz/App42_ANDROID_SDK/blob/master/Change_Log_MA.md#version-20)
* [Release Version 1.1](https://github.com/shephertz/App42_ANDROID_SDK/blob/master/Change_Log_MA.md#version-11)
* [Release Version 1.0](https://github.com/shephertz/App42_ANDROID_SDK/blob/master/Change_Log_MA.md#version-10)

## Version 3.1

**Release Date:** 03-03-2016 

**Release Version:** 3.1

**The following features have been added to the Marketing Automation SDK :**

**Custom inApp Dialog**

**MA SDK as a library **

**This release contains the following bug fix:**

```
None
```
## Version 3.0

**Release Date:** 27-01-2016 

**Release Version:** 3.0

**The following features have been added to the Marketing Automation SDK :**

**App Virality API**

**Coupon code management in InAppMessages**

**MA SDK as a library **

**This release contains the following bug fix:**

```
None
```

## Version 2.0

**Release Date:** 16-06-2015 

**Release Version:** 2.0

**The following features have been added to the Marketing Automation SDK :**

**InAppMessages**

* Survey added in InApp messages

**This release contains the following bug fix:**

```
None
```

## Version 1.1

**Release Date:** 19-05-2015 

**Release Version:** 1.1

**This release contains the following bug fix:**

```
InApp message shown on currentActivity of application
```


## Version 1.0

**Release Date:** 20-01-2015 

**Release Version:** 1.0

**The following features have been pushed to the Marketing Automation SDK :**

**InAppMessages**
App42 releases Marketing Automation SDK of inAppMessages.

* Alert Dialog
* Confirmation Dialog
* Interstitial Dialog 

**App42CampaignAPI**

```
App42CampaignAPI.enable(isEnable);
App42CampaignAPI.setConfigCacheTime(timeInMin);
```


**This release contains the following bug fix:**

```
None
```
